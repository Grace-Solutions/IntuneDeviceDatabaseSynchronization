# Intune Device Sync Service

A production-ready Rust service for synchronizing Microsoft Intune device data to multiple database backends with advanced filtering, metrics, and observability features.

## 🚀 Features

- **Multi-Database Support**: SQLite, PostgreSQL, and MSSQL backends
- **Device OS Filtering**: Flexible filtering with wildcard and substring matching
- **OAuth2 Authentication**: Silent client credentials flow with automatic token refresh
- **Prometheus Metrics**: Comprehensive observability with custom metrics
- **Service Management**: Native Windows service support with CLI commands
- **Shadow Metadata**: Stores unmapped device fields in separate metadata tables
- **Hash-based Change Detection**: Efficient updates using device fingerprinting
- **Structured Logging**: Component-based logging with rotation and sanitization
- **Configuration Flexibility**: JSON config files with environment variable overrides

## 📦 Installation

### Prerequisites

- Rust 1.75 or later
- Microsoft Azure App Registration with appropriate permissions
- Database server (PostgreSQL/MSSQL) if using external databases

### Build from Source

#### Automated Build (Recommended)
The project includes an automated build system with version management:

```powershell
# Simple build (Release configuration)
.\build.ps1

# Debug build
.\build.ps1 -Configuration Debug

# Skip tests and specify output directory
.\build.ps1 -SkipTests -OutputDir "C:\MyBuilds"

# Or use the batch file wrapper
.\build.bat
```

The automated build system:
- ✅ Generates timestamp-based versions (yyyy.MM.dd.HHmm)
- ✅ Embeds Windows icon and version information
- ✅ Creates distribution packages
- ✅ Runs tests automatically
- ✅ Generates build metadata

#### Manual Build
```bash
git clone <repository-url>
cd IntuneDeviceDatabaseSynchronization
cargo build --release
```

#### Version Management
The project uses automatic timestamp-based versioning:
- **Format**: `yyyy.MM.dd.HHmm` (e.g., `2025.01.02.1430`)
- **Embedded**: Version info is embedded in the Windows executable
- **Accessible**: Version info available via `--version` or `version` command

### Docker

```bash
docker build -t intune-device-sync .
docker run -d \
  -v $(pwd)/config.json:/app/config.json \
  -v $(pwd)/logs:/app/logs \
  -p 9898:9898 \
  intune-device-sync
```

## ⚙️ Configuration

### Azure App Registration

1. Create an Azure App Registration
2. Grant the following Microsoft Graph permissions:
   - `DeviceManagementManagedDevices.Read.All`
   - `Directory.Read.All` (optional, for additional device info)
3. Create a client secret
4. Note the Client ID, Client Secret, and Tenant ID

### Configuration File

Create `config.json`:

```json
{
  "clientId": "your-azure-client-id",
  "clientSecret": "your-azure-client-secret",
  "tenantId": "your-azure-tenant-id",
  "pollInterval": "1h",
  "deviceOsFilter": ["Windows", "macOS", "Android"],
  "enablePrometheus": true,
  "prometheusPort": 9898,
  "prometheusScrapeInterval": "0 */30 * * * *",
  "database": {
    "backends": ["sqlite", "postgres"],
    "sqlitePath": "./output/devices.db",
    "postgres": {
      "connectionString": "postgres://user:pass@host:5432/db"
    },
    "mssql": {
      "connectionString": "Server=.;Database=Sync;User Id=sa;Password=Secret!",
      "tableName": "devices"
    }
  }
}
```

### Environment Variables

Environment variables override JSON configuration:

```bash
GRAPH_CLIENT_ID=your-client-id
GRAPH_CLIENT_SECRET=your-client-secret
GRAPH_TENANT_ID=your-tenant-id
POLL_INTERVAL=30m
DEVICE_OS_FILTER=Windows,macOS
ENABLE_PROMETHEUS=true
PROMETHEUS_PORT=9898
MSSQL_CONNECTION_STRING=Server=.;Database=Sync;...
RUST_LOG=info
```

## 🎛️ Device OS Filtering

The service supports flexible OS filtering:

| Filter Value | Matches | Notes |
|--------------|---------|-------|
| `"*"` | All devices | Wildcard (default) |
| `"windows"` | "Windows", "Windows 10" | Case-insensitive |
| `"mac"` | "macOS", "Mac OS X" | Substring matching |
| `"android"` | "Android" | Direct match |

Examples:
- `["*"]` - Include all devices
- `["Windows", "macOS"]` - Only Windows and macOS devices
- `["windows", "android"]` - Windows and Android devices

## 🖥️ Service Management

### Windows Service

```bash
# Install as Windows service
intune-device-sync install

# Start the service
intune-device-sync start

# Stop the service
intune-device-sync stop

# Restart the service
intune-device-sync restart

# Check service status
intune-device-sync status

# Uninstall the service
intune-device-sync uninstall
```

### Foreground Mode

```bash
# Run in foreground (for development/testing)
intune-device-sync run
```

## 📊 Database Schema

### Main Device Table

```sql
CREATE TABLE devices (
    uuid UUID PRIMARY KEY,
    device_name TEXT,
    operating_system TEXT,
    os_version TEXT,
    serial_number TEXT,
    imei TEXT,
    model TEXT,
    manufacturer TEXT,
    enrolled_date_time TIMESTAMPTZ,
    last_sync_date_time TIMESTAMPTZ,
    compliance_state TEXT,
    azure_ad_device_id TEXT,
    device_hash TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### Metadata Table

```sql
CREATE TABLE device_metadata (
    uuid UUID,
    field_name TEXT,
    raw_value TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (uuid, field_name),
    FOREIGN KEY (uuid) REFERENCES devices(uuid) ON DELETE CASCADE
);
```

## 📈 Prometheus Metrics

Access metrics at `http://localhost:9898/metrics`

### Available Metrics

- `sync_success_total` - Successful sync operations
- `sync_failure_total` - Failed sync operations
- `sync_duration_seconds` - Sync operation duration
- `devices_fetched_total` - Devices fetched from Intune
- `devices_processed_total` - Devices processed
- `devices_current_count` - Current device count
- `device_filter_matched_total` - Devices allowed by OS filter
- `device_filter_skipped_total` - Devices skipped by OS filter
- `token_refresh_total` - Token refresh operations
- `auth_failure_total` - Authentication failures
- `db_insert_total` - Database insert operations
- `db_update_total` - Database update operations
- `db_skip_total` - Database operations skipped (no changes)
- `db_error_total` - Database errors
- `http_requests_total` - HTTP requests made
- `http_errors_total` - HTTP errors

## 🔧 Development

### Running Tests

```bash
cargo test
```

### Debug Logging

```bash
RUST_LOG=debug cargo run -- run
```

### Database Migrations

The service automatically creates required tables and indexes on startup.

## 🐳 Docker Compose Example

```yaml
version: '3.8'
services:
  intune-sync:
    build: .
    environment:
      - GRAPH_CLIENT_ID=${GRAPH_CLIENT_ID}
      - GRAPH_CLIENT_SECRET=${GRAPH_CLIENT_SECRET}
      - GRAPH_TENANT_ID=${GRAPH_TENANT_ID}
      - DEVICE_OS_FILTER=Windows,macOS
    volumes:
      - ./logs:/app/logs
      - ./output:/app/output
    ports:
      - "9898:9898"
    restart: unless-stopped
```

## 🔒 Security

- Secrets are only stored in environment variables or config files
- All log output is sanitized to remove sensitive information
- Database connections use secure connection strings
- OAuth2 tokens are cached securely and refreshed automatically

## 📝 Logging

Logs are written to `logs/intune-device-sync.log` with rotation:

```
2025/01/02 15:30:45.123 - [1234] - [ThreadID] - [INFO] - [Sync] - Starting device sync operation
2025/01/02 15:30:46.456 - [1234] - [ThreadID] - [INFO] - [Filter] - Allowed device 'DESKTOP-ABC123' with OS 'Windows'
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the GPL-3.0 License - see the [LICENSE](LICENSE) file for details.